# UDP Tunnel

<div align="right">


 - ابتدا سرور ایران را آپدیت کنید
<div align="left">
 
```
apt update -y && apt upgrade -y
```
<div align="right">


 - اسکریپت راه اندازی تانل بین سرور ایران و خارج
<div align="left">
 
```
bash <(curl -Ls https://raw.githubusercontent.com/amirmbn/UDP2RAW/main/udp2raw.sh)
```
<div align="right">


 - شماره 1 مربوط به نصب udp2raw است
 - شماره 2 و 3 مربوط به تنظیمات سرور ایران و خارج میباشد.
